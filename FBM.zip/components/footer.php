<style>
  .footer {
  background-color: #373737;
  color: white;
  padding: 20px;
  text-align: center;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 200px;
  transition: height 1s;
}

  @media(max-width: 400px){
    .foot{
      font-size: 10px;
      img{
        width: 30px;
      }
    }
  }
</style>

<div class="footer foot">
  <div class="container" style="display: flex;">
    <div class="container">
      © 2023 Todos os Direitos Reservados</br>
      Projeto criado por Laboratória STAR</br>
      Site desenvolvido por <a href="https://www.linkedin.com/in/luan-silva-3385542b4/" style="color: cyan; font-weight: bold;">
        Luan Silva
      </a>
    </div>
    </br>
      Instagram: <a href="https://www.instagram.com/luan_silvakw/" target="_blank">
        <img style="border-radius: 100%; margin-right: 12px;" src="https://png.pngtree.com/png-clipart/20230401/original/pngtree-three-dimensional-instagram-icon-png-image_9015419.png" width="50px">
      </a>
    </br>  
    </div>
  </div>
  </div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>
</html>