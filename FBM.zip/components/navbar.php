<nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid" style="background-color: black; height: 120px;">
        <a class="navbar-brand" href="../index.php" style="color: orange; font-size: xx-large; font-weight: 600;">FBM</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mb-2 mb-lg-0" style="margin-right: 50% !important;">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#" style="color: orange; font-weight: 600;">INICIO</a>
                </li>
            </ul>
            <form class="d-flex" style="background-color: white;
              border-radius: 20px;">
                <input style="border-radius: 20px 0px 0px 20px;
                  border: none;" class="form-control me-2 mx-auto" type="search" placeholder="Search" aria-label="Search">
                <button style="border: none; color: black;" class="btn" type="submit"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <circle cx="11" cy="11" r="8" />
                  <line x1="21" y1="21" x2="16.65" y2="16.65" />
                </svg></button>
            </form>
            <ul class="navbar-nav">
              <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false" style="color: orange; font-weight: 600;">
                      Perfil
                  </a>
                  <ul class="dropdown-menu">
                      <li><a class="dropdown-item" href="#">Perfil do usuario</a></li>
                      <li><a class="dropdown-item" href="#">Configurações</a></li>
                      <li><hr class="dropdown-divider"></li>
                      <li><a class="dropdown-item" href="#">Sair</a></li>
                  </ul>
              </li>
            </ul>
        </div>
    </div>
</nav>
