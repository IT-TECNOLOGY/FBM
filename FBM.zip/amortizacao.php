<?php include './components/header.php'; ?>
    <title>Amortização</title>
  </head>
<?php include './components/navbar.php'; ?>
<body>

  <style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #f4f4f4;
    }

    #calculator {
        max-width: 600px;
        margin: 50px auto;
        padding: 20px;
        background-color: #fff;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    input{
      margin-bottom: 10px;
      border: 3px solid orange;
      border-radius: 9px;
      color: black;
      height: 43px;
    }
    button {
        margin-bottom: 10px;
    }

    table {
        width: 100%;
        margin-top: 20px;
        border-collapse: collapse;
    }

    table, th, td {
        border: 1px solid #ddd;
    }

    th, td {
        padding: 10px;
        text-align: center;
    }

    button {
        background-color: #4caf50;
        color: #fff;
        border: none;
        padding: 10px 15px;
        cursor: pointer;
    }

  </style>

  
    <div id="calculator">
          <h2>Calculadora de Amortização SAC</h2>
      <div style="display: flex;">
          <div class="container">
          <label for="loanAmount">Valor do Empréstimo:</label><br>
          <input type="number" id="loanAmount" min="0" placeholder="Insira o valor do empréstimo"><br>
  
          <label for="interestRate">Taxa de Juros Anual (%):</label><br>
          <input type="number" id="interestRate" min="0" placeholder="Insira a taxa de juros anual"><br>
  
          <label for="loanTerm">Número de Parcelas:</label><br>
          <input type="number" id="loanTerm" min="0" placeholder="Insira o número de parcelas"><br>
  
          <button onclick="calculateAmortization()">Calcular Amortização</button>
          </div>
          <div class="container">
            O Sistema de Amortização Constante é um método de pagamento de empréstimos onde o valor das prestações é constante, mas a composição entre juros e amortização varia ao longo do tempo.
          </div>
      </div>

        <table id="amortizationTable">
            <thead>
                <tr>
                    <th>Parcela</th>
                    <th>Valor Parcela</th>
                    <th>Juros</th>
                    <th>Amortização</th>
                    <th>Saldo Devedor</th>
                </tr>
            </thead>
            <tbody>
                <!-- As linhas da tabela serão adicionadas dinamicamente aqui -->
            </tbody>
        </table>
    </div>

  <script>
    function calculateAmortization() {
        // Obter valores do formulário
        var loanAmount = parseFloat($('#loanAmount').val());
        var interestRate = parseFloat($('#interestRate').val()) / 100 / 12; // Taxa mensal
        var loanTerm = parseInt($('#loanTerm').val());

        // Calcular amortização SAC
        var monthlyPayment = loanAmount * (interestRate * Math.pow(1 + interestRate, loanTerm)) / (Math.pow(1 + interestRate, loanTerm) - 1);

        // Limpar tabela
        $('#amortizationTable tbody').empty();

        // Preencher tabela com amortizações
        var remainingBalance = loanAmount;
        for (var i = 1; i <= loanTerm; i++) {
            var interest = remainingBalance * interestRate;
            var principal = monthlyPayment - interest;

            $('#amortizationTable tbody').append(
                '<tr>' +
                '<td>' + i + '</td>' +
                '<td>' + monthlyPayment.toFixed(2) + '</td>' +
                '<td>' + interest.toFixed(2) + '</td>' +
                '<td>' + principal.toFixed(2) + '</td>' +
                '<td>' + remainingBalance.toFixed(2) + '</td>' +
                '</tr>'
            );

            remainingBalance -= principal;
        }
    }

  </script>
</body>
  <script src="./script.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</html>
