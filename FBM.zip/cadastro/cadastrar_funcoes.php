<?php include '../components/header.php'; ?>
    <title>FBM</title>
  </head>
<?php include '../components/navbar.php'; ?>
  <body>
    <style>
      .input{
        width: 50px;
        height: 50px;
        margin: 3px;
      }

      .info{
        width: 30%;
        border: 2px solid;
        padding: 5px;
        font-size: 20px;
      }

      .selecionadosTable{
        width: 70%;
        border: 2px solid;
      }

      tr{
        font-size: 20px;
        cursor: pointer;
      }

    </style>
<div class="text-center">
  <h1>Seja bem-vindo ao Full Business Manager!</h1>
</div>
    <div>
      <h3>Aqui você escolherá os sistemas que mais achar necessários à sua empresa.</h3>
      <h3><b>Lembrando!!</b> Essas funções funcionarão de forma automática, e aparecerá para você de forma informativa.</h3>
    </div>
    <div style="display: flex;">
        <div class="info">
          
        </div>
      <div class="selecionadosTable">
        <table class="table">
          <thead>
            <tr>
              <th scope="col">ID</th>
              <th scope="col">Função</th>
              <th scope="col">Selecionado?</th>
              <th scope="col">Simular</th>
              <th scope="col">Valor unitário</th>
            </tr>
          </thead>
          <tbody>
            <tr class="Gprodutos">
              <th scope="row">1</th>
              <td>Gestão de produtos</td>
              <td><input hidden class="input gestaoP" type="checkbox"><p></p></td>
              <td><a href="../simulacao/gerenciarProdutos.php" target="_blank"><button class="btn btn-danger" id="simularGP">Simular</button></a></td>
              <td>Indefinido</td>
            </tr>
            <tr class="Smercado">
              <th scope="row">2</th>
              <td>Sistema de mercado</td>
              <td><input hidden class="input sistemaM" type="checkbox"><p></p></td>
              <td><a href="#" target="_blank"><button class="btn btn-danger" id="simularSM">Simular</button></a></td>
              <td>Indefinido</td>
            </tr>
            <tr class="Gfuncionarios">
              <th scope="row">3</th>
              <td>Gestão de funcionários</td>
              <td><input hidden class="input gestaoF" type="checkbox"><p></p></td>
              <td><a href="#" target="_blank"><button class="btn btn-danger" id="simularGF">Simular</button></a></td>
              <td>Indefinido</td>
            </tr>
            <tr class="curvaABC">
              <th scope="row">3</th>
              <td>Curva ABC</td>
              <td><input hidden class="input ABCcurva" type="checkbox"><p></p></td>
              <td><a href="#" target="_blank"><button class="btn btn-danger" id="simularABC">Simular</button></a></td>
              <td>Indefinido</td>
            </tr>
            <tr class="Contracheque">
              <th scope="row">4</th>
              <td>Contracheque</td>
              <td><input hidden class="input cheque" type="checkbox"><p></p></td>
              <td><a href="#" target="_blank"><button class="btn btn-danger" id="simularABC">Simular</button></a></td>
              <td>Indefinido</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    <script>
      $(document).ready(function(){

        $('.Gprodutos, .Smercado, .Gfuncionarios, .curvaABC, .Contracheque').find('p').html('X').css('color', 'red');
        $('.Gprodutos, .Smercado, .Gfuncionarios, .curvaABC, .Contracheque').find('td, th').css('background-color', '#ff95a9');
        
        // Adiciona um manipulador de eventos quando o mouse entra na div .Gprodutos
        $('.Gprodutos').on('mouseenter', function(){
          var texto = '<center><h2>Gestão de produtos</h2></center>Cadastre seus produtos e tenha uma gestão totalmente automatizada de vendas, preços e estoque.<br>Com a função sistema de mercado, você pode não só gerenciar como controlar suas vendas.';
          $('.info').html(texto);
        });
        
        // Adiciona um manipulador de eventos quando o mouse entra na div .Smercado
        $('.Smercado').on('mouseenter', function(){
          var texto = '<center><h2>Sistema de mercado</h2></center>Diferente da gestão de produtos, o sistema de mercado é uma função que você pode usar para controlar suas vendas no próprio caixa.<br>Sem dispositivos complexos, apenas uma webcam ou seu celular, você pode usar para ler seus produtos com um código QR, e automaticamente o produto passado irá aparecer no sistema do caixa.';
          $('.info').html(texto);
        });

        // Adiciona um manipulador de eventos quando o mouse entra na div .Gfuncionarios
        $('.Gfuncionarios').on('mouseenter', function(){
          var texto = '<center><h2>Gerenciar funcionários</h2></center>Com o sistema de gerenciamento de funcionários, você pode ter controle de entrada e saida dos funcionários, bem como horarios e salários.';
          $('.info').html(texto);
        });

        // Adiciona um manipulador de eventos quando o mouse entra na div .curvaABC
        $('.curvaABC').on('mouseenter', function(){
          var texto = '<center><h2>Curva <l class="a">A</l><l class="b">B</l><l class="c">C</l></h2></center></h2></center>Veja quais são os produtos que você mais vendeu no mês, e seus preços. A função curva ABC é uma função que você pode usar para analisar seus produtos e verificar se estão em um padrão de venda. Ainda consta com uma análise e um <a href="../infos.php?info=pareto">gráfico de pareto</a>.';
          $('.info').html(texto);
          $('.a').css('color', 'green');
          $('.b').css('color', 'orange');
          $('.c').css('color', 'red');
        });
        // Adiciona um manipulador de eventos quando o mouse entra na div .curvaABC
        $('.Contracheque').on('mouseenter', function(){
          var texto = '<center><h2>Contracheque</h2></center>Aqui você poderá ter uma gestão completa dos seus funcionários, bem como horários de entrada e saída, faltas e horas extras, para assim gerar automáticamente um contracheque para cada funcionário. Como podemos ver na <a href="../scc/scc.php" target="_blank">demonstração</a>.';
          $('.info').html(texto);
          $('.a').css('color', 'green');
          $('.b').css('color', 'orange');
          $('.c').css('color', 'red');
        });

        // Adiciona um manipulador de eventos quando a div .Gprodutos for clicada
        $('.Gprodutos, .Smercado, .Gfuncionarios, .curvaABC, .Contracheque').on('click', function(){
            // Seleciona o input dentro da div .Gprodutos e define seu estado como checked
            if($(this).find('input').is(':checked')){
                $(this).find('input').prop('checked', false);
                $(this).find('p').html('X').css('color', 'red');
              $(this).find('td, th').css('color', 'black');
                $(this).find('td, th').css('background-color', '#ff95a9');
            } else {
                $(this).find('input').prop('checked', true);
                $(this).find('p').html('✔️').css('color', 'green');
                $(this).find('td, th').css('background-color', '#9cffa9');
            }
        });

        $('.Gprodutos, .Smercado, .Gfuncionarios, .curvaABC, .Contracheque').hover(function(){
            var currentColor = $(this).find('td, th').css('background-color');

            if(currentColor === 'rgb(156, 255, 169)'){ // Verde
                $(this).find('td, th').css('background-color', 'rgb(72, 123, 79)'); // Muda para outro tom de verde
              $(this).find('td, th').css('color', 'white');
            } else if(currentColor === 'rgb(255, 149, 169)'){ // Vermelho
                $(this).find('td, th').css('background-color', 'rgb(165, 42, 69)'); // Muda para outro tom de vermelho
              $(this).find('td, th').css('color', 'white');
            }
        }, function(){ // Define a cor de fundo de volta quando o mouse sai
            var currentColor = $(this).find('td, th').css('background-color');

            if(currentColor === 'rgb(72, 123, 79)'){ // Verde
                $(this).find('td, th').css('background-color', 'rgb(156, 255, 169)');
              $(this).find('td, th').css('color', 'black');
            } else if(currentColor === 'rgb(165, 42, 69)'){ // Vermelho
                $(this).find('td, th').css('background-color', 'rgb(255, 149, 169)');
              $(this).find('td, th').css('color', 'black');
            }
        });
          
      });
    </script>
    <script src="https://rawgit.com/schmich/instascan-builds/master/instascan.min.js"></script>
<?php include '../components/footer.php'; ?>