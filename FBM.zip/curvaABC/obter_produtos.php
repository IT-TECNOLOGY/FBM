<?php
  $file = 'produtos.json';
  $jsonString = file_get_contents($file);
  header('Content-Type: application/json');
  echo $jsonString;
?>