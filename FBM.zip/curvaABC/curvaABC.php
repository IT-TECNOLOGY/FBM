<?php include '../components/header.php'; ?>
<title>Curva ABC</title>
</head>
<?php include '../components/navbar.php'; ?>

<body>
  <div class="text-center">
    <h2>Curva ABC</h2>
  </div>
  <div>
    <button class="btn btn-success" id="addProduto">Adicionar produto</button>
    <button class="btn btn-success" id="filtrar">Filtrar</button>
  </div>
  <table class="table">
    <thead>
      <tr>
        <th scope="col">PRODUTO</th>
        <th scope="col">CONSUMO FINAL</th>
        <th scope="col">PREÇO</th>
        <th scope="col">VALOR FINAL</th>
        <th scope="col">% INDIVIDUAL</th>
        <th scope="col">% ACUMULADA</th>
        <th scope="col">CLASSIFICAÇÃO</th>
        <th scope="col">Excluir</th>
      </tr>
    </thead>
    <tbody id="produtoTable">
      <!-- ... -->
    </tbody>
    <tbody>
      <tr>
        <td colspan="3" style="text-align: end;"><b>Total final:</b></td>
        <td id="totalFinal"></td>
    </tbody>
  </table>
  <button class="btn btn-success" id="analisar" style="margin: 2%;">Análise</button>
  <div style="width: 50%; margin: 2%;" id="analise">
    
  </div>
  <div>
    <canvas id="paretoChart" width="400" height="200"></canvas>
  </div>

  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script>
    $(document).ready(function() {
      // Adiciona um novo produto
      $('#addProduto').click(function() {
        var newRow = '<tr>' +
          '<td><input type="text" class="form-control produto"></td>' +
          '<td><input type="number" class="form-control consumo"></td>' +
          '<td><input type="number" class="form-control preco"></td>' +
          '<td class="valor-final">0</td>' +
          '<td class="percentual-individual">0%</td>' +
          '<td class="percentual-acumulada">0%</td>' +
          '<td class="classificacao"></td>' +
          '<td class="excluir"><button class="btn btn-danger">Excluir</button></td>' +
          '</tr>';

        $('#produtoTable').append(newRow);

        // Após adicionar o produto, atualiza o localStorage
        atualizarLocalStorage();
      });

      function atualizarLocalStorage() {
        var produtos = [];

        // Itera sobre as linhas da tabela para obter os dados dos produtos
        $('#produtoTable tr').each(function(index) {
          produtos.push({
            produto: $(this).find('.produto').val(),
            consumo: parseFloat($(this).find('.consumo').val()) || 0,
            preco: parseFloat($(this).find('.preco').val()) || 0
          });
        });

        // Salva o array de produtos no localStorage
        localStorage.setItem('produtos', JSON.stringify(produtos));
      }

      // Verifica se há dados no localStorage
      var produtosArmazenados = localStorage.getItem('produtos');

      if (produtosArmazenados) {
        // Converte os dados do localStorage de volta para um array de objetos
        produtos = JSON.parse(produtosArmazenados);

        // Atualiza a tabela com os dados armazenados
        atualizarTabela();
      }

      function atualizarTabela() {
        // Limpa a tabela
        $('#produtoTable').empty();

        // Ordena os produtos em ordem decrescente com base no valorFinal
        produtos.sort(function(a, b) {
          return b.consumo * b.preco - a.consumo * a.preco;
        });

        // Adiciona linhas à tabela com base nos dados armazenados
        produtos.forEach(function(produto) {
          var newRow = '<tr>' +
            '<td><input type="text" class="form-control produto" value="' + produto.produto + '"></td>' +
            '<td><input type="number" class="form-control consumo" value="' + produto.consumo + '"></td>' +
            '<td><input type="number" class="form-control preco" value="' + produto.preco + '"></td>' +
            '<td class="valor-final">0</td>' +
            '<td class="percentual-individual">0%</td>' +
            '<td class="percentual-acumulada">0%</td>' +
            '<td class="classificacao"></td>' +
            '<td class="excluir"><button class="btn btn-danger">Excluir</button></td>' +
            '</tr>';

          $('#produtoTable').append(newRow);
        });

        // Atualiza os cálculos
        calcularValores();
      }

      function calcularValores() {
        var totalConsumo = 0;
        var produtos = [];

        // Calcula o total de consumo e armazena os valores dos inputs
        $('#produtoTable tr').each(function(index) {
            var consumo = parseFloat($(this).find('.consumo').val()) || 0;
            totalConsumo += consumo;

            var preco = parseFloat($(this).find('.preco').val()) || 0;
            var valorFinal = consumo * preco;

            produtos.push({
                produto: $(this).find('.produto').val(),
                consumo: consumo,
                preco: preco,
                valorFinal: valorFinal  // Adiciona o valor final ao objeto produto
            });
        });

        // Calcula o total final
        var totalFinal = 0;
        produtos.forEach(function(produto) {
          totalFinal += produto.consumo * produto.preco;
        });

        // Atualiza os valores nas colunas correspondentes
        $('#produtoTable tr').each(function(index) {
          var consumo = parseFloat($(this).find('.consumo').val()) || 0;
          var preco = parseFloat($(this).find('.preco').val()) || 0;
          var valorFinal = consumo * preco;
          var percentualIndividual = (valorFinal / totalFinal) * 100;

          $(this).find('.valor-final').text(valorFinal.toFixed(2));
          $(this).find('.percentual-individual').text(percentualIndividual.toFixed(2) + '%');

          // Calcula o percentual acumulado
          var percentualAcumulado = 0;
          for (var i = 0; i <= index; i++) {
            // Obtém o valor individual da célula
            var percentualIndividualLinha = parseFloat($('#produtoTable tr').eq(i).find('.percentual-individual').text().replace('%', '')) || 0;
            percentualAcumulado += percentualIndividualLinha;
          }

          // Atualiza a percentagem acumulada na célula correspondente
          $(this).find('.percentual-acumulada').text(percentualAcumulado.toFixed(2) + '%');

          // Adiciona a classificação
          var classificacao = '';
          if (percentualAcumulado <= 80) {
            classificacao = 'A';
          } else if (percentualAcumulado <= 95) {
            classificacao = 'B';
          } else {
            classificacao = 'C';
          }

          $(this).find('.classificacao').text(classificacao);

          // Remove classes de fundo antes de adicionar a classe correspondente
          $(this).find('.classificacao').removeClass('bg-success bg-warning bg-danger');

          // Adiciona a classificação
          if (percentualAcumulado <= 80) {
            $(this).find('.classificacao').addClass('bg-success');
          } else if (percentualAcumulado <= 95) {
            $(this).find('.classificacao').addClass('bg-warning');
          } else {
            $(this).find('.classificacao').addClass('bg-danger');
          }
        });

        // Atualiza o total final na tabela
        $('#totalFinal').text("R$" + totalFinal.toFixed(2).replace(".", ","));

        
        // Atualiza o localStorage após os cálculos
        atualizarLocalStorage();
        
        criarGraficoPareto(produtos);
        
      }

      function criarGraficoPareto(data) {
          var labels = data.map(function(item) {
              return item.produto;
          });

          var valores = data.map(function(item) {
              return item.valorFinal;
          });

          // Adiciona cores personalizadas com base nos percentuais
          var cores = data.map(function(item) {
              var percentualLucro = (item.valorFinal / valores.reduce((a, b) => a + b, 0)) * 100;

              if (percentualLucro >= 10) {
                  return 'rgba(50, 205, 50, 0.6)';
              } else if (percentualLucro >= 5) {
                  return 'rgba(255, 255, 0, 0.6)';
              } else {
                  return 'rgba(255, 0, 0, 0.6)';
              }
          });

        // Destrói o gráfico existente, se houver
        if (window.paretoChart instanceof Chart) {
            window.paretoChart.destroy();
        }

          // Cria um novo gráfico com as cores personalizadas
          var ctx = document.getElementById('paretoChart').getContext('2d');
          window.paretoChart = new Chart(ctx, {
              type: 'bar',
              data: {
                  labels: labels,
                  datasets: [{
                      label: 'Valor Final',
                      data: valores,
                      backgroundColor: cores,
                      borderColor: 'rgba(75, 192, 192, 1)',
                      borderWidth: 1
                  }]
              },
              options: {
                  scales: {
                      y: {
                          beginAtZero: true
                      }
                  }
              }
          });
      }

      // Adiciona um evento de clique aos botões "Excluir"
      $('#produtoTable').on('click', '.excluir button', function() {
        $(this).closest('tr').remove(); // Remove a linha mais próxima ao botão clicado
        calcularValores(); // Recalcula os valores após a exclusão
      });


      // Adiciona um evento de clique ao botão "Filtrar"
      $('#filtrar').click(function() {
        // Chama a função para realizar o filtro
        filtrarValores();
      });

      // Função para realizar o filtro
      function filtrarValores() {
        // Obtém os produtos do localStorage
        var produtosArmazenados = localStorage.getItem('produtos');

        if (produtosArmazenados) {
          // Converte os dados do localStorage de volta para um array de objetos
          var produtos = JSON.parse(produtosArmazenados);

          // Ordena os produtos em ordem decrescente com base no valor final
          produtos.sort(function(a, b) {
            return (b.consumo * b.preco) - (a.consumo * a.preco);
          });

          // Limpa a tabela
          $('#produtoTable').empty();

          // Adiciona linhas à tabela com base nos dados ordenados
          produtos.forEach(function(produto) {
            var newRow = '<tr>' +
              '<td><input type="text" class="form-control produto" value="' + produto.produto + '"></td>' +
              '<td><input type="number" class="form-control consumo" value="' + produto.consumo + '"></td>' +
              '<td><input type="number" class="form-control preco" value="' + produto.preco + '"></td>' +
              '<td class="valor-final">0</td>' +
              '<td class="percentual-individual">0%</td>' +
              '<td class="percentual-acumulada">0%</td>' +
              '<td class="classificacao"></td>' +
              '<td class="excluir"><button class="btn btn-danger">Excluir</button></td>' +
              '</tr>';

            $('#produtoTable').append(newRow);
          });

          // Recalcula os valores após o filtro
          calcularValores();
        }
      }

      // Função para recalcular os valores a cada 200ms
      setInterval(function() {

          $('.consumo').change(function() {
              filtrarValores();
          });

          $('.preco').change(function() {
              filtrarValores();
          });

        

      }, 1000);

      // Adiciona um evento de input aos campos de consumo e preço
      $('#produtoTable').on('input', '.consumo, .preco', function() {
          calcularValores();  // Recalcula os valores
          criarGraficoPareto();  // Atualiza o gráfico
      });

      $('#analisar').click(function() {
          var produtosA = [];
          var produtosB = [];
          var produtosC = [];

          // Itera sobre as linhas da tabela
          $('#produtoTable tr').each(function(index) {
              var classificacao = $(this).find('.classificacao').text();
              var produtoNome = $(this).find('.produto').val();

            // Verifica se o nome do produto está vazio
            if (produtoNome.trim() === '') {
                produtoNome = '[Produto Sem Nome]';
            }

              // Adiciona o nome do produto ao array correspondente
              if (classificacao === 'A') {
                  produtosA.push(produtoNome);
              } else if (classificacao === 'B') {
                  produtosB.push(produtoNome);
              } else if (classificacao === 'C') {
                  produtosC.push(produtoNome);
              }

            

          });

          var analise = "";

          // Adiciona texto para o Grupo A
          if (produtosA.length > 0) {
              analise += "Com base na análise da curva ABC e da classificação de valor, é evidente que os produtos de maior valor, como " + produtosA.join(', ') + ", são essenciais para o desempenho financeiro da [Nome da empresa]. Portanto, esses produtos devem receber atenção prioritária em termos de estratégias de marketing, promoção e gestão de estoque.<br><br>";
          }

          // Adiciona texto para o Grupo B
          if (produtosB.length > 0) {
              analise += "Produtos do Grupo B, como " + produtosB.join(', ') + ", também têm importância significativa, enquanto os do Grupo C contribuem menos para o faturamento total, mas ainda têm um papel a desempenhar.<br><br>";
          }

          // Adiciona texto para o Grupo C
          if (produtosC.length > 0) {
             analise += "Ao analisar os produtos do Grupo C, é possível perceber que, em relação ao faturamento total, esses produtos contribuem menos significativamente. Embora sua participação seja menor, cada item do Grupo C desempenha um papel importante na oferta geral da empresa.<br><br>";  // Adicione o texto adequado para o Grupo C
          }

          // Adiciona o restante do texto
          analise += "Recomendo que a empresa continue monitorando regularmente o desempenho desses produtos e ajuste suas estratégias com base nessas análises para otimizar os resultados financeiros. <br><br>Atenciosamente.<br><br>[FBM]";

          // Exibe a análise na div #analise
          $('#analise').html(analise);
      });
      
      
    });
  </script>

  <?php include '../components/footer.php'; ?>
</body>
</html>