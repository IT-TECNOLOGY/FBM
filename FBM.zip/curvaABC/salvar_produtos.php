<?php
  $jsonString = file_get_contents('php://input');
  $data = json_decode($jsonString);

  if ($data !== null) {
    $file = 'produtos.json';
    file_put_contents($file, json_encode($data));
  }
?>
