<?php include '../components/header.php'; ?>
<title>Balanço Patrimonial</title>
</head>
<?php include '../components/navbar.php'; ?>

<body>
  <style>
    input {
      border: none;
    }

    @media screen and (max-width: 500px) {
      div {
        width: 125%;
        box-sizing: border-box;
      }

      .removeButton {
        display: block;
        margin-top: 10px; /* Adiciona um espaçamento acima do botão Remover */
      }
    }
  </style>
<div>
  <div style="display: flex; flex-wrap: wrap;">
    <div style="width: 50%;">
      <table class="table">
        <thead>
          <tr>
            <th scope="col">Ativos <button class="btn btn-success" id="addAtivo">Adicionar Ativo</button></th>
          </tr>
        </thead>
        <tbody id="ativosTable">
        </tbody>
        <tbody>
            <tr id="totalAC"></tr>
        </tbody>
      </table>
    </div>
    <div style="width: 50%;">
      <table class="table">
        <thead>
          <tr>
            <th scope="col">Passivos <button class="btn btn-success" id="addPassivo">Adicionar Passivo</button></th>
          </tr>
        </thead>
        <tbody id="passivosTable">
        </tbody>
        <tbody>
            <tr id="totalPC"></tr>
        </tbody>
      </table>
    </div>
  </div>

  <div style="display: flex; flex-wrap: wrap;">
    <div style="width: 50%;">
      <table class="table">
        <thead>
          <tr>
            <th scope="col">Ativo não circulante <button class="btn btn-success" id="addANC">Adicionar ANC</button></th>
          </tr>
        </thead>
        <tbody id="ANcirculanteTable">
        </tbody>
        <tbody>
            <tr id="totalANC"></tr>
        </tbody>
      </table>
    </div>
    <div style="width: 50%;">
      <table class="table">
        <thead>
          <tr>
            <th scope="col">Passivo não circulante <button class="btn btn-success" id="addPNC">Adicionar PNC</button></th>
          </tr>
        </thead>
        <tbody id="PNcirculanteTable">
        </tbody>
        <tbody>
            <tr id="totalPNC"></tr>
        </tbody>
      </table>
    </div>
  </div>

  <div style="display: flex; flex-direction: row-reverse;">
    <div style="width: 50%;">
      <table class="table">
        <thead>
          <tr>
            <th scope="col">Patrimonio Liquido <button class="btn btn-success" id="addPatrimonio">Adicionar Patrimonio</button></th>
          </tr>
        </thead>
        <tbody id="patrimonioTable">
        </tbody>
        <tbody>
            <tr id="totalPL"></tr>
        </tbody>
      </table>
    </div>
  </div>

  <div style="display: flex; flex-wrap: wrap;">
    <div style="width: 50%;">
      <table class="table">
        <thead>
          <tr>
            <th scope="col">Total Ativos</th>
          </tr>
        </thead>
        <tbody>
          <tr id="totalAtivos">
          </tr>
        </tbody>
      </table>
    </div>
    <div style="width: 50%;">
      <table class="table">
        <thead>
          <tr>
            <th scope="col">Total passivos </th>
          </tr>
        </thead>
        <tbody>
          <tr id="totalPassivos">
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</div>
  <div>
    <table class="table">
      <thead>
        <tr>
          <th scope="col">CAPITAL PRÓPRIO</th>
          <th scope="col">CAPITAL DE TERCEIROS</th>
          <th scope="col">CAPITAL TOTAL INVESTIDO</th>
        </tr>
      </thead>
      <tbody id="totais">
      </tbody>
    </table>
  </div>
  <div>
    <table class="table">
      <thead>
        <tr>
          <th scope="col">INDICIE DE LIQUIDEZ CORRENTE (AC/PC)</th>
          <th scope="col">INDICIE DE LIQUIDEZ SECA (AC - estoque/PC)</th>
          <th scope="col">INDICIE DE LIQUIDEZ IMEDIATA (AC - estoque - contas a receber / PC)</th>
          <th scope="col">INDICIE DE LIQUIDEZ GERAL ((AC - ANC)/(PC+PNC))</th>
        </tr>
      </thead>
      <tbody id="indicies">
      </tbody>
    </table>
  </div>

  <!-- Certifique-se de incluir o jQuery antes do seu script -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script>
    $(document).ready(function() {
      // Adiciona ativo
      $('#addAtivo').click(function() {
        var ativo = '<tr><td><input type="text" class="form-control" placeholder="Nome do Ativo"></td><td><input type="number" class="form-control pegaA" placeholder="Valor do Ativo"></td><td><button class="btn btn-danger removeAtivo">Remover</button></td></tr>';
        $('#ativosTable').append(ativo);
      });

      // Adiciona passivo
      $('#addPassivo').click(function() {
        var passivo = '<tr><td><input type="text" class="form-control" placeholder="Nome do Passivo"></td><td><input type="number" class="form-control pegaP" placeholder="Valor do Passivo"></td><td><button class="btn btn-danger removePassivo">Remover</button></td></tr>';
        $('#passivosTable').append(passivo);
      });

      // Adiciona ativo não circulante
      $('#addANC').click(function() {
        var Nc = '<tr><td><input type="text" class="form-control" placeholder="Nome do Ativo não circulante"></td><td><input type="number" class="form-control pegaANC" placeholder="Valor do Ativo não circulante"></td><td><button class="btn btn-danger removeNC">Remover</button></td></tr>';
        $('#ANcirculanteTable').append(Nc);
      });

      // Adiciona passivo não circulante
      $('#addPNC').click(function() {
        var Pnc = '<tr><td><input type="text" class="form-control" placeholder="Nome do Passivo não circulante"></td><td><input type="number" class="form-control pegaPNC" placeholder="Valor do Passivo não circulante"></td><td><button class="btn btn-danger removePNC">Remover</button></td></tr>';
        $('#PNcirculanteTable').append(Pnc);
      });

      // Adiciona patrimônio líquido
      $('#addPatrimonio').click(function() {
        var patrimonio = '<tr><td><input type="text" class="form-control" placeholder="Nome do Patrimonio"></td><td><input type="number" class="form-control pegaPL" placeholder="Valor do Patrimonio"></td><td><button class="btn btn-danger removePatrimonio">Remover</button></td></tr>';
        $('#patrimonioTable').append(patrimonio);
      });

      // Adiciona um evento de clique aos botões "Remover"
      $('#ativosTable, #passivosTable, #ANcirculanteTable, #PNcirculanteTable, #patrimonioTable').on('click', '.removeAtivo, .removePassivo, .removeNC, .removePNC, .removePatrimonio', function() {
        $(this).closest('tr').remove(); // Remove a linha mais próxima ao botão clicado
      });

      // Função para recalcular os totais
      setInterval(function() {
        var pegaA = 0;
        var pegaP = 0;
        var totalA = 0;
        var totalAC = 0;
        var totalP = 0;
        var totalPC = 0;
        var totalANC = 0;
        var ANCtotal = 0;
        var totalPNC = 0;
        var PNCtotal = 0;
        var totalPL = 0;
        var PLtotal = 0;

        // Ativos
        $('.pegaA').each(function() {
          var valor = parseFloat($(this).val()) || 0;
          pegaA += valor;
          totalAC += valor;
        });

        // Passivos
        $('.pegaP').each(function() {
          var valor2 = parseFloat($(this).val()) || 0;
          pegaP += valor2;
          totalPC += valor2;
        });

        // Ativos não circulantes
        $('.pegaANC').each(function() {
          var valor3 = parseFloat($(this).val()) || 0;
          totalANC += valor3;
          ANCtotal += valor3;
        });

        // Passivos não circulantes
        $('.pegaPNC').each(function() {
          var valor4 = parseFloat($(this).val()) || 0;
          totalPNC += valor4;
          PNCtotal += valor4;
        });

        // Patrimônio líquido
        $('.pegaPL').each(function() {
          var valor5 = parseFloat($(this).val()) || 0;
          totalPL += valor5;
          PLtotal += valor5;
        });

        totalA = pegaA + totalANC;
        totalP = pegaP + totalPNC + totalPL;

        // Adiciona a condição para verificar se totalA é igual a totalP
        if (totalA === totalP && totalA !== 0) {
          var color = 'green';
        } else {
          var color = 'red';
        }

        // Atualiza os valores dos campos de total formatados como moeda
        $('#totalAtivos').html('<td colspan="3" style="text-align: right; font-size: 23px; color: ' + color + '">R$ ' + totalA.toFixed(2).replace('.', ',').replace(/(\d)(?=(\d{3})+,)/g, '$1.') + '</td>');
        
        $('#totalPassivos').html('<td colspan="3" style="text-align: right; font-size: 23px; color: ' + color + '">R$ ' + totalP.toFixed(2).replace('.', ',').replace(/(\d)(?=(\d{3})+,)/g, '$1.') + '</td>');
        
        $('#totalAC').html('<td colspan="3" style="text-align: right; font-size: 23px;"><b>Total: </b>R$ ' + totalAC.toFixed(2).replace('.', ',').replace(/(\d)(?=(\d{3})+,)/g, '$1.') + '</td>');
        
        $('#totalPC').html('<td colspan="3" style="text-align: right; font-size: 23px;"><b>Total: </b>R$ ' + totalPC.toFixed(2).replace('.', ',').replace(/(\d)(?=(\d{3})+,)/g, '$1.') + '</td>');
        
        $('#totalPNC').html('<td colspan="3" style="text-align: right; font-size: 23px;"><b>Total: </b>R$ ' + PNCtotal.toFixed(2).replace('.', ',').replace(/(\d)(?=(\d{3})+,)/g, '$1.') + '</td>');
        
        $('#totalANC').html('<td colspan="3" style="text-align: right; font-size: 23px;"><b>Total: </b>R$ ' + ANCtotal.toFixed(2).replace('.', ',').replace(/(\d)(?=(\d{3})+,)/g, '$1.') + '</td>');
        
        $('#totalPL').html('<td colspan="3" style="text-align: right; font-size: 23px;"><b>Total: </b>R$ ' + PLtotal.toFixed(2).replace('.', ',').replace(/(\d)(?=(\d{3})+,)/g, '$1.') + '</td>');

  // Calcula totais de capitais
  var capitalProprio = totalPL;
  var capitalTerceiros = totalPNC + totalP;
  var capitalTotalInvestido = totalA;

  // Atualiza os totais de capitais na tabela
  $('#totais').html(`
    <tr>
      <td>${capitalProprio.toFixed(2).replace('.', ',')}</td>
      <td>${capitalTerceiros.toFixed(2).replace('.', ',')}</td>
      <td>${capitalTotalInvestido.toFixed(2).replace('.', ',')}</td>
    </tr>
  `);

        // Função para verificar se há a palavra 'estoque'
        function verificarPalavras() {

            // Percorre todos os inputs
            $('input').each(function() {
                var valorInput = $(this).val().toLowerCase(); // Converte para minúsculas para ser case-insensitive
                if (valorInput.indexOf('estoque') !== -1) {
                    var estoqueEncontrado = true;

                    // Recupera o valor do ativo na mesma linha do input onde foi encontrado o estoque
                    var valorAtivo = $(this).closest('tr').find('.pegaA').val();

                    // Faça o que deseja com o valor do ativo, por exemplo, exibir no console
                    console.log('Valor do Ativo relacionado ao estoque:', valorAtivo);

                    return false; // Sai do loop assim que encontrar a palavra
                }

              if (valorInput.indexOf('a receber') !== -1) {
                  receberEncontrado = true;

                  // Recupera o valor do ativo na mesma linha do input onde foi encontrado o estoque
                  var a_receber = $(this).closest('tr').find('.pegaA').val();

                  // Faça o que deseja com o valor do ativo, por exemplo, exibir no console
                  console.log('Valor do Ativo relacionado a "a receber":', a_receber);

                  return false; // Sai do loop assim que encontrar a palavra
              }

              
            });

            return estoqueEncontrado;
            return receberEncontrado;
        }

        // Verifica se há a palavra 'estoque' nos inputs
        var estoqueEncontrado = verificarPalavras();
        var receberEncontrado = verificarPalavras();

        // Calcula totais de capitais
        var capitalProprio = totalPL;
        var capitalTerceiros = totalPNC + totalP;
        var capitalTotalInvestido = totalA;

        // Atualiza os totais de capitais na tabela
        $('#totais').html(`
            <tr>
                <td>${capitalProprio.toFixed(2).replace('.', ',')}</td>
                <td>${capitalTerceiros.toFixed(2).replace('.', ',')}</td>
                <td>${capitalTotalInvestido.toFixed(2).replace('.', ',')}</td>
            </tr>
        `);

        var estoque;
        var receber;

        // Calcula índices de liquidez apenas se a palavra 'estoque' for encontrada
        if (estoqueEncontrado) {
            // Recupera o valor do ativo relacionado ao estoque
            estoque = parseFloat($(this).closest('tr').find('.pegaA').val()) || 0;
        } else {
            // Caso a palavra 'estoque' não seja encontrada, você pode exibir uma mensagem ou realizar outra ação
            console.log('Palavra "estoque" não encontrada nos inputs.');
          estoque = 0;
        }

        // Calcula índices de liquidez apenas se a palavra 'estoque' for encontrada
        if (receberEncontrado) {
            // Recupera o valor do ativo relacionado ao estoque
            receber = parseFloat($(this).closest('tr').find('.pegaA').val()) || 0;
        } else {
            // Caso a palavra 'receber' não seja encontrada, você pode exibir uma mensagem ou realizar outra ação
            console.log('Palavra "receber" não encontrada nos inputs.');
          receber = 0;
        }

        var indiceLiquidezCorrente = (totalAC / totalPC) || 0;
        var indiceLiquidezSeca = ((totalAC - estoque) / totalP) || 0;
        var indiceLiquidezImediata = ((totalAC - estoque - receber) / totalPC) || 0;
        var indiceLiquidezGeral = ((totalAC - ANCtotal) / (totalPC + PNCtotal)) || 0;

        // Atualiza os índices de liquidez na tabela
        $('#indicies').html(`<tr>
            <td>${indiceLiquidezCorrente.toFixed(2)}</td>
            <td>${indiceLiquidezSeca.toFixed(2)}</td>
            <td>${indiceLiquidezImediata.toFixed(2)}</td>
            <td>${indiceLiquidezGeral.toFixed(2)}</td>
        </tr>`);

    }, 200);
    });
  </script>

  <?php include '../components/footer.php'; ?>
</body>
</html>
