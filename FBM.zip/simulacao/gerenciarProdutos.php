<?php include '../components/header.php'; ?>
<title>FBM</title>
</head>
<?php include '../components/navbar.php'; ?>
<body>
  <style>
    #produtos {
      display: flex;
      flex-wrap: wrap; /* Permite que os cards quebrem para a próxima linha */
    }

    .card {
      width: 18rem;
      margin: auto; /* Margem entre os cards */
      margin-top: 20px;
    }

    #ftProd{
      width: 60px;
    }
  </style>
  <div style="display: flex; padding: 1%;">
    <div>
      <input class="input" placeholder="busque pelo produto">
      <button class="btn btn-primary" id="buscar">Buscar</button>
      <button class="btn btn-success" id="adicionar">Adicionar produto</button>
    </div>
    <div>
    </div>
  </div>
  <div style="display: flex; padding: 1%;" id="produtos">
  </div>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script>
    var num_prod = 0;
    var nome = "";
    var preco = 0;
    var estq = 0;
    $('#adicionar').click(function(){
      num_prod++;
      estq++;
      preco += 10;
      nome = "Produto " + num_prod;

      var novoCard = `<div class="card" style="width: 18rem;">
        <div class="card-body"> 
          <h5 class="card-title">Produto: ${nome}</h5>
          <h6 class="card-subtitle mb-2 text-muted">Preço: R$${parseFloat(preco).toFixed(2)}</h6>
          <p class="card-text">Quantidade: ${estq}</p>
          <button class="btn btn-danger" onclick="removeProd(${num_prod})">Remover produto</button>
          <button class="btn btn-warning" onclick="editarProd(${num_prod})">Editar produto</button>
        </div>
      </div>`;
      $('#produtos').append(novoCard);
    });

    function removeProd(id) {
      // Encontra o card correspondente ao ID
      var cardToRemove = $('#produtos').find('.card').eq(id - 1);

      // Remove o card
      cardToRemove.remove();

      // Atualiza os IDs dos cards restantes
      $('#produtos').find('.card').each(function(index) {
        $(this).find('button').attr('onclick', 'removeProd(' + (index + 1) + ')');
      });
    }
  </script>
<?php include '../components/footer.php'; ?>