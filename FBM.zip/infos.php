<?php include '../components/header.php'; ?>
    <title>FBM</title>
  </head>
<?php include '../components/navbar.php'; ?>
  <body>

<?php include './components/footer.php'; ?>