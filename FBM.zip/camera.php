<video id="preview"></video>
<button id="startScan">Iniciar leitura</button>
<script>
  document.getElementById('startScan').addEventListener('click', function() {
    let scanner = new Instascan.Scanner({ video: document.getElementById('preview') });
    scanner.addListener('scan', function(content) {
      alert('QR code lido: ' + content);
    });
    Instascan.Camera.getCameras().then(function(cameras) {
      if (cameras.length > 0) {
        // Se houver mais de uma câmera, exiba uma opção para o usuário escolher
        if (cameras.length > 1) {
          let cameraId = prompt('Selecione a câmera:\n\n' + cameras.map((camera, index) => `${index + 1}: ${camera.name}`).join('\n'));
          scanner.start(cameras[parseInt(cameraId) - 1]);
        } else {
          // Se houver apenas uma câmera, inicie a leitura diretamente
          scanner.start(cameras[0]);
        }
      } else {
        console.error('Nenhuma câmera encontrada.');
      }
    }).catch(function(e) {
      console.error(e);
    });
  });
</script>